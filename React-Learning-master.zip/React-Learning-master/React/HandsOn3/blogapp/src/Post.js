class Post{
    constructor(id, title, body){
        this.id = id;
        this.title = title;
        this.body = body;
    }
    // render(){
    //     return <article>
    //         <div>
    //             <p>{this.id}</p>
    //             <p>{this.title}</p>
    //             <p>{this.body}</p>
    //         </div>
    //     </article>
    // }
}

export default Post;