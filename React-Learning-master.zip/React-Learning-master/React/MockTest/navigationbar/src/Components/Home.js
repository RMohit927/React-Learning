import React from "react";

const Home = () => {
  return (
    <div className="container">
      <h2>Home Page</h2>
      {/* <div className="underline" /> */}
    </div>
  );
};

const News = () => {
  return (
    <div className="container">
      <h2>News Page</h2>
      {/* <div className="underline" /> */}
    </div>
  );
};

const Contact = () => {
  return (
    <div className="container">
      <h2>Contact Page</h2>
      {/* <div className="underline" /> */}
    </div>
  );
};

const About = () => {
  return (
    <div className="container">
      <h2>About Page</h2>
      {/* <div className="underline" /> */}
    </div>
  );
};

export { Home, News, Contact, About };
