import React, { Component } from 'react'

class Home extends Component {
  render() {
    return (
      <div>
        <b><h2>Welcome to My Academy trainers page</h2></b>
      </div>
    )
  }
}

export default Home;