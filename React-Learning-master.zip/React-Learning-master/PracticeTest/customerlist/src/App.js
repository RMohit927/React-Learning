import CustomerList from "./Components/index";
import "../node_modules/bootstrap/dist/css/bootstrap.css";

function App() {
  return (
    <div className="App">
      <CustomerList />
    </div>
  );
}

export default App;
